module Reline
  VERSION = '0.3.1'
end
