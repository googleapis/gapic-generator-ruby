# frozen_string_literal: false
# DO NOT WRITE ANY MAGIC COMMENT HERE.
module IRB
  def self.default_src_encoding
    return __ENCODING__
  end
end
