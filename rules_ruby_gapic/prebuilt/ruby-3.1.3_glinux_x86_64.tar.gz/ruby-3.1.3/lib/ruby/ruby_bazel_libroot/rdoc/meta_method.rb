# frozen_string_literal: true
##
# MetaMethod represents a meta-programmed method

class RDoc::MetaMethod < RDoc::AnyMethod
end

