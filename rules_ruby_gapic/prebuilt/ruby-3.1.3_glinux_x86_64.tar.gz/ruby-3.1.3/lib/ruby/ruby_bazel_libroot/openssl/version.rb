# frozen_string_literal: true

module OpenSSL
  VERSION = "3.0.1"
end
