# frozen_string_literal: true

module RBS
  VERSION = "2.7.0"
end
