# frozen_string_literal: true

module Bundler
  module Persistent
    module Net
      module HTTP
      end
    end
  end
end
require_relative "vendor/net-http-persistent/lib/net/http/persistent"
