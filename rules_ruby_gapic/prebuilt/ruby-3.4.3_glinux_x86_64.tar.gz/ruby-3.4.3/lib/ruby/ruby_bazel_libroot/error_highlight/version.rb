module ErrorHighlight
  VERSION = "0.7.0"
end
