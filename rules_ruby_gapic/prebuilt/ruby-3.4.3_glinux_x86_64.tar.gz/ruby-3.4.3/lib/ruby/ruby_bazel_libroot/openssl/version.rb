# frozen_string_literal: true

module OpenSSL
  VERSION = "3.3.0"
end
