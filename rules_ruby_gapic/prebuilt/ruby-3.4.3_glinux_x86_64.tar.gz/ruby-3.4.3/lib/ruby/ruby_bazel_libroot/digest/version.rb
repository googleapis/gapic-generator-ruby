# frozen_string_literal: true

module Digest
  VERSION = "3.2.0"
end
