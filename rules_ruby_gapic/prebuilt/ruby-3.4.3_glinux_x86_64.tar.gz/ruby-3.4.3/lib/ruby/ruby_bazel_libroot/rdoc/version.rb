# frozen_string_literal: true

module RDoc

  ##
  # RDoc version you are using

  VERSION = '6.10.0'

end
