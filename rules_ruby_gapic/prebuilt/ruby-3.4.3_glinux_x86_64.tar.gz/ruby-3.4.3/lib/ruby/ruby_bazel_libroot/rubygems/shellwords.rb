# frozen_string_literal: true

autoload :Shellwords, "shellwords"
