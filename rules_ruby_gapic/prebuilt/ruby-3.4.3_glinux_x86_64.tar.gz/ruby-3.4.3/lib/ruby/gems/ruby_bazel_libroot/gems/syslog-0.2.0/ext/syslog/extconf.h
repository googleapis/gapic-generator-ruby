#ifndef EXTCONF_H
#define EXTCONF_H
#define HAVE_SYSLOG_H 1
#define HAVE_OPENLOG 1
#define HAVE_SETLOGMASK 1
#endif
