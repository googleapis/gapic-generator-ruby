require "optparse"
require "pathname"
require "io/console"

require_relative "cli/cli"
