module TypeProf
  VERSION = "0.30.1"
end
