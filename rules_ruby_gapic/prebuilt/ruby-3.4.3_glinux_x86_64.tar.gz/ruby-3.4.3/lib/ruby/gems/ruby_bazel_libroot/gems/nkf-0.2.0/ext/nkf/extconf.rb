# frozen_string_literal: false
require 'mkmf'
create_makefile('nkf')
