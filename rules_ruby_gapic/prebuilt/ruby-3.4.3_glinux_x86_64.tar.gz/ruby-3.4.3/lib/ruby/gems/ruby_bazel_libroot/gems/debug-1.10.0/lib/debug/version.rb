# frozen_string_literal: true

module DEBUGGER__
  VERSION = "1.10.0"
end
