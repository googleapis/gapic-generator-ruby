# frozen_string_literal: false
require_relative 'optparse'
