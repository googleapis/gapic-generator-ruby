require 'support/packed_field'
require 'support/server'

def now
  Time.new.to_f
end
