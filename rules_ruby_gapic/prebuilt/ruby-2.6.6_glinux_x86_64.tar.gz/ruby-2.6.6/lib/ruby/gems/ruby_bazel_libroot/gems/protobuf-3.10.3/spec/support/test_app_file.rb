# For use in testing the rpc_server
ENV['TEST_APP_FILE_LOADED'] = 'true'
