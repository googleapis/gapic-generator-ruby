#--
# Copyright (c) 2007-2013 Nick Sieger.
# See the file README.txt included with the distribution for
# software license details.
#++

module MultipartPost
  VERSION = "2.1.1"
end
