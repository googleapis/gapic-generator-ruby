module Open3
  VERSION = "0.1.2"
end
