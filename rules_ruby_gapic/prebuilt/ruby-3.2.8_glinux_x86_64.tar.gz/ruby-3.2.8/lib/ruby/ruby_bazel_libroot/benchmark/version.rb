# frozen_string_literal: true
module Benchmark
  VERSION = "0.2.1"
end
