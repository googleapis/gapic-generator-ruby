class ThreadsWait
  VERSION = "0.1.0"
end
